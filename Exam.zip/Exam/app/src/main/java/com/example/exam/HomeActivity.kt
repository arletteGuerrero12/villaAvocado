package com.example.exam

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.exam.adapters.DiplomadosAdapter
import com.example.exam.adapters.MateriasAdapter
import com.example.exam.data.database.AppDatabaseHelper
import com.example.exam.data.database.DiplomadoDao
import com.example.exam.data.database.DiplomadoMateriaDao
import com.example.exam.data.database.MateriasDao
import com.example.exam.data.database.UsuarioDiplomadoDao
import com.example.exam.data.repository.DiplomadoMateriaRepository
import com.example.exam.data.repository.DiplomadoRepository
import com.example.exam.data.repository.MateriasRepository
import com.example.exam.data.repository.UsuarioDiplomadoRepository
import com.google.android.material.floatingactionbutton.FloatingActionButton

class HomeActivity : AppCompatActivity() {

    private lateinit var rvDiplomados: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val dbHelper = AppDatabaseHelper(this)
        val diplomadoDao = DiplomadoDao(dbHelper)
        val diplomadoRepository = DiplomadoRepository(diplomadoDao)
        val usuarioDiplomadoDao = UsuarioDiplomadoDao(dbHelper)
        val usuarioDiplomadoRepository = UsuarioDiplomadoRepository(usuarioDiplomadoDao)
        val materiasDao = MateriasDao(dbHelper)
        val materiasRepository = MateriasRepository(materiasDao)
        val diplomadoMateriaDao = DiplomadoMateriaDao(dbHelper)
        val diplomadoMateriaRepository = DiplomadoMateriaRepository(diplomadoMateriaDao)
val btnAdd: FloatingActionButton = findViewById(R.id.btnAdd)

        val userId = intent.getIntExtra("USER_ID", -1)

        rvDiplomados = findViewById(R.id.rvDiplomados)
        rvDiplomados.layoutManager = LinearLayoutManager(this)

        if (userId != -1) {
            val todosLosDiplomados = diplomadoRepository.obtenerDiplomado()
            val relacionesUsuario = usuarioDiplomadoRepository.obtenerTodasLasRelaciones()
            val idsDiplomadosDelUsuario = relacionesUsuario
                .filter { it.idUsuario == userId }
                .map { it.idDiplomado }
                .toSet()
            val diplomadosDelUsuario = todosLosDiplomados.filter { it.id in idsDiplomadosDelUsuario }

            val todasLasMaterias = materiasRepository.obtenerMaterias()
            val todasLasRelacionesMateria = diplomadoMateriaRepository.obtenerDiplomadoMaterias()
            val materiasPorDiplomadoId = todasLasRelacionesMateria
                .groupBy { it.idDiplomado }
                .mapValues { entry ->
                    val materiaIds = entry.value.map { it.idMateria }.toSet()
                    todasLasMaterias.filter { it.id in materiaIds }
                }

            diplomadosDelUsuario.forEach {
                it.materias = materiasPorDiplomadoId[it.id] ?: emptyList()
            }

            rvDiplomados.adapter = DiplomadosAdapter(diplomadosDelUsuario) { diplomado ->
                // Lógica para mostrar las materias del diplomado (la que antes estaba en el adapter)
                val dialogView = layoutInflater.inflate(R.layout.materias_dialog, null)
                val rvMateriasInDialog: RecyclerView = dialogView.findViewById(R.id.rvMaterias)

                rvMateriasInDialog.layoutManager = LinearLayoutManager(this)
                rvMateriasInDialog.adapter = MateriasAdapter(diplomado.materias)

                AlertDialog.Builder(this)
                    .setTitle("Materias de " + diplomado.nombre)
                    .setView(dialogView)
                    .setPositiveButton("Cerrar", null)
                    .show()
            }
        } else {
            // Manejar error
        }
        btnAdd.setOnClickListener {
            val intent = Intent(this, CertifiedActivity::class.java)
            startActivity(intent)
        }
    }
}
