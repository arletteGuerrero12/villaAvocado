package com.example.exam.data.database

import android.content.ContentValues
import com.example.exam.models.Diplomado

class DiplomadoDao(private val dbHelper: AppDatabaseHelper) {

    fun insert(diplomado: Diplomado): Long {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("nombre", diplomado.nombre)
            put("descripcion", diplomado.descripcion)
            put("isActivo", diplomado.isActivo)
            put("fechaInserto", diplomado.fechaInserto)
            put("fechaInicio", diplomado.fechaInicio)
            put("fechaFin", diplomado.fechaFin)
        }
        return db.insert("Diplomado", null, values)
    }

    fun getAll(): List<Diplomado> {
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM Diplomado", null)
        val lista = mutableListOf<Diplomado>()

        if (cursor.moveToFirst()) {
            do {
                lista.add(
                    Diplomado(
                        id = cursor.getInt(0),
                        nombre = cursor.getString(1),
                        descripcion = cursor.getString(2),
                        isActivo = cursor.getInt(3),
                        fechaInserto = cursor.getString(4),
                        fechaInicio = cursor.getString(5),
                        fechaFin = cursor.getString(6)
                    )
                )
            } while (cursor.moveToNext())
        }

        cursor.close()
        return lista
    }

    fun getById(id: Int): Diplomado? {
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM Diplomado WHERE id = ?", arrayOf(id.toString()))
        var diplomado: Diplomado? = null
        if (cursor.moveToFirst()) {
            diplomado = Diplomado(
                id = cursor.getInt(0),
                nombre = cursor.getString(1),
                descripcion = cursor.getString(2),
                isActivo = cursor.getInt(3),
                fechaInserto = cursor.getString(4),
                fechaInicio = cursor.getString(5),
                fechaFin = cursor.getString(6)
            )
        }
        cursor.close()
        return diplomado
    }

    fun update(diplomado: Diplomado): Int {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("nombre", diplomado.nombre)
            put("descripcion", diplomado.descripcion)
            put("isActivo", diplomado.isActivo)
            put("fechaInserto", diplomado.fechaInserto)
            put("fechaInicio", diplomado.fechaInicio)
            put("fechaFin", diplomado.fechaFin)
        }
        return db.update("Diplomado", values, "id = ?", arrayOf(diplomado.id.toString()))
    }

    fun delete(id: Int): Int {
        val db = dbHelper.writableDatabase
        return db.delete("Diplomado", "id = ?", arrayOf(id.toString()))
    }
}
