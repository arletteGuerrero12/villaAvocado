package com.example.exam.models

data class UsuarioDiplomado(
    val idUsuario: Int,
    val idDiplomado: Int
)
