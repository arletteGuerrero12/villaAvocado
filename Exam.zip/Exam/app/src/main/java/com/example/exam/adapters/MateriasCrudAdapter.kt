package com.example.exam.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.exam.R
import com.example.exam.models.Materias

class MateriasCrudAdapter(
    private val materias: List<Materias>,
    private val onItemClicked: (Materias) -> Unit
) : RecyclerView.Adapter<MateriasCrudAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        // Usaremos un layout simple para mostrar el nombre y la duración
        val tvNombre: TextView = view.findViewById(android.R.id.text1)
        val tvDuracion: TextView = view.findViewById(android.R.id.text2)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // Android provee layouts simples que podemos usar para esto
        val view = LayoutInflater.from(parent.context)
            .inflate(android.R.layout.simple_list_item_2, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val materia = materias[position]
        holder.tvNombre.text = materia.nombre
        holder.tvDuracion.text = "Duración: ${materia.duracion} horas"
        holder.itemView.setOnClickListener { onItemClicked(materia) }
    }

    override fun getItemCount(): Int = materias.size
}
