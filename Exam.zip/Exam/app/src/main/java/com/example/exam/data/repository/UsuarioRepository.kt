package com.example.exam.data.repository

import com.example.exam.data.database.UsuarioDao
import com.example.exam.models.Usuario

class UsuarioRepository(private val usuarioDao: UsuarioDao) {

    fun agregarUsuario(usuario: Usuario) = usuarioDao.insert(usuario)

    fun obtenerUsuarios() = usuarioDao.getAll()

    fun eliminarUsuario(id: Int) = usuarioDao.delete(id)

    fun actualizarUsuario(usuario: Usuario) = usuarioDao.update(usuario)

    fun obtenerUsuarioPorId(id: Int) = usuarioDao.getById(id)
}
