package com.example.exam

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class AdminActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)
        val usuario = findViewById<FrameLayout>(R.id.cardUsuario)
        val materia = findViewById<FrameLayout>(R.id.cardMateria)
        val diplomado = findViewById<FrameLayout>(R.id.cardDiplomado)

        // Lógica de redirección para los botones
        usuario.setOnClickListener {
            startActivity(Intent(this, UserActivity::class.java))
        }

        materia.setOnClickListener {
            startActivity(Intent(this, MateriaActivity::class.java))
        }

        diplomado.setOnClickListener {
            startActivity(Intent(this, DiplomadoActivity::class.java))
        }


        setCircleColor(usuario, "#3F51B5")   // Azul
        setCircleColor(materia, "#4CAF50")   // Verde
        setCircleColor(diplomado, "#FF9800") // Naranja
    }

    private fun setCircleColor(circle: FrameLayout, colorHex: String) {
        val bg = circle.background.mutate()
        if (bg is android.graphics.drawable.GradientDrawable) {
            bg.setColor(android.graphics.Color.parseColor(colorHex))
        }
    }

}