package com.example.exam.data.database

import android.content.ContentValues
import com.example.exam.models.Usuario

class UsuarioDao(private val dbHelper: AppDatabaseHelper) {

    fun insert(usuario: Usuario): Long {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("usuario", usuario.usuario)
            put("pass", usuario.pass)
            put("idTipoUsuario", usuario.idTipoUsuario)
        }
        return db.insert("Usuario", null, values)
    }

    fun getAll(): List<Usuario> {
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM Usuario", null)

        val lista = mutableListOf<Usuario>()

        if (cursor.moveToFirst()) {
            do {
                lista.add(
                    Usuario(
                        id = cursor.getInt(0),
                        usuario = cursor.getString(1),
                        pass = cursor.getString(2),
                        idTipoUsuario = cursor.getInt(3)
                    )
                )
            } while (cursor.moveToNext())
        }

        cursor.close()
        return lista
    }

    fun getById(id: Int): Usuario? {
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM Usuario WHERE id = ?", arrayOf(id.toString()))
        var usuario: Usuario? = null
        if (cursor.moveToFirst()) {
            usuario = Usuario(
                id = cursor.getInt(0),
                usuario = cursor.getString(1),
                pass = cursor.getString(2),
                idTipoUsuario = cursor.getInt(3)
            )
        }
        cursor.close()
        return usuario
    }

    fun update(usuario: Usuario): Int {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("usuario", usuario.usuario)
            put("pass", usuario.pass)
            put("idTipoUsuario", usuario.idTipoUsuario)
        }
        return db.update("Usuario", values, "id = ?", arrayOf(usuario.id.toString()))
    }

    fun delete(id: Int): Int {
        val db = dbHelper.writableDatabase
        return db.delete("Usuario", "id = ?", arrayOf(id.toString()))
    }
}
