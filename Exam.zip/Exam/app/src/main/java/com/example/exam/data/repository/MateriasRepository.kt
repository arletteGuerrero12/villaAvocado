package com.example.exam.data.repository

import com.example.exam.data.database.MateriasDao
import com.example.exam.models.Materias


class MateriasRepository (private val materiasDao: MateriasDao) {

    fun agregarMateria(materia: Materias) = materiasDao.insert(materia)

    fun obtenerMaterias() = materiasDao.getAll()

    fun eliminarMateria(id: Int) = materiasDao.delete(id)

    fun actualizarMateria(materia: Materias) = materiasDao.update(materia)

    fun obtenerMateriaPorId(id: Int) = materiasDao.getById(id)
}
