package com.example.exam

import android.app.AlertDialog
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.exam.adapters.DiplomadosAdapter
import com.example.exam.data.database.AppDatabaseHelper
import com.example.exam.data.database.DiplomadoDao
import com.example.exam.data.database.DiplomadoMateriaDao
import com.example.exam.data.database.MateriasDao
import com.example.exam.data.database.UsuarioDiplomadoDao
import com.example.exam.data.repository.DiplomadoMateriaRepository
import com.example.exam.data.repository.DiplomadoRepository
import com.example.exam.data.repository.MateriasRepository
import com.example.exam.data.repository.UsuarioDiplomadoRepository
import com.example.exam.models.Diplomado
import com.example.exam.models.UsuarioDiplomado
import java.text.SimpleDateFormat
import java.util.Locale

class CertifiedActivity : AppCompatActivity() {

    // Declarar repositorios y userId como propiedades de la clase
    private lateinit var diplomadoRepository: DiplomadoRepository
    private lateinit var usuarioDiplomadoRepository: UsuarioDiplomadoRepository
    private var userId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cetified)

        // --- Inicialización de Repositorios ---
        val dbHelper = AppDatabaseHelper(this)
        diplomadoRepository = DiplomadoRepository(DiplomadoDao(dbHelper))
        val materiasRepository = MateriasRepository(MateriasDao(dbHelper))
        val diplomadoMateriaRepository = DiplomadoMateriaRepository(DiplomadoMateriaDao(dbHelper))
        usuarioDiplomadoRepository = UsuarioDiplomadoRepository(UsuarioDiplomadoDao(dbHelper))

        // Suponiendo que el userId se pasa a esta actividad. Si no es así, necesitas obtenerlo.
        // Por ejemplo, podrías obtenerlo de SharedPreferences si lo guardas al iniciar sesión.
        // Para este ejemplo, lo quemaré a 3 (el id de 'maria') para que la lógica funcione.
        userId = 3 // ** ¡OJO: Reemplazar con la forma real de obtener el userId! **

        val todosLosDiplomados = diplomadoRepository.obtenerDiplomado()
        val todasLasMaterias = materiasRepository.obtenerMaterias()
        val todasLasRelaciones = diplomadoMateriaRepository.obtenerDiplomadoMaterias()

        val materiasPorDiplomadoId = todasLasRelaciones
            .groupBy { it.idDiplomado }
            .mapValues { entry ->
                val materiaIds = entry.value.map { it.idMateria }.toSet()
                todasLasMaterias.filter { it.id in materiaIds }
            }

        todosLosDiplomados.forEach {
            it.materias = materiasPorDiplomadoId[it.id] ?: emptyList()
        }

        val recyclerView: RecyclerView = findViewById(R.id.rvDiplomados)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Pasar la función lambda con la lógica de inscripción
        recyclerView.adapter = DiplomadosAdapter(todosLosDiplomados) { diplomadoSeleccionado ->
            // Aquí va toda la lógica de validación e inscripción
            inscribirUsuarioSiEsValido(diplomadoSeleccionado)
        }
    }

    private fun inscribirUsuarioSiEsValido(diplomadoAInscribir: Diplomado) {
        // 1. Obtener los diplomados que el usuario YA tiene
        val todosLosDiplomados = diplomadoRepository.obtenerDiplomado()
        val relacionesUsuario = usuarioDiplomadoRepository.obtenerTodasLasRelaciones()
        val idsDiplomadosDelUsuario = relacionesUsuario
            .filter { it.idUsuario == userId }
            .map { it.idDiplomado }
            .toSet()
        val diplomadosDelUsuario = todosLosDiplomados.filter { it.id in idsDiplomadosDelUsuario }

        // 2. Verificar si ya está inscrito
        if (diplomadoAInscribir.id in idsDiplomadosDelUsuario) {
            Toast.makeText(this, "Ya estás inscrito en este diplomado.", Toast.LENGTH_SHORT).show()
            return
        }

        // 3. Validar si las fechas se empalman
        val seEmpalma = diplomadosDelUsuario.any { diplomadoExistente ->
            fechasSeEmpalman(diplomadoExistente, diplomadoAInscribir)
        }

        if (seEmpalma) {
            // Si se empalma, mostrar error
            AlertDialog.Builder(this)
                .setTitle("Conflicto de Horario")
                .setMessage("Las fechas de este diplomado se empalman con uno al que ya estás inscrito. No puedes inscribirte.")
                .setPositiveButton("Entendido", null)
                .show()
        } else {
            // Si no se empalma, confirmar e inscribir
            AlertDialog.Builder(this)
                .setTitle("Confirmar Inscripción")
                .setMessage("¿Deseas inscribirte a '${diplomadoAInscribir.nombre}'?")
                .setPositiveButton("Sí, Inscribirme") { _, _ ->
                    usuarioDiplomadoRepository.agregarUsuarioDiplomado(UsuarioDiplomado(userId, diplomadoAInscribir.id))
                    Toast.makeText(this, "¡Inscripción exitosa!", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }
    }

    private fun fechasSeEmpalman(d1: Diplomado, d2: Diplomado): Boolean {
        val format = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        try {
            val inicio1 = format.parse(d1.fechaInicio)
            val fin1 = format.parse(d1.fechaFin)
            val inicio2 = format.parse(d2.fechaInicio)
            val fin2 = format.parse(d2.fechaFin)

            // Un empalme ocurre si (Inicio1 <= Fin2) y (Inicio2 <= Fin1)
            return !inicio1.after(fin2) && !inicio2.after(fin1)
        } catch (e: Exception) {
            // En caso de error de formato, asumir que no se empalman para no bloquear al usuario
            return false
        }
    }
}
