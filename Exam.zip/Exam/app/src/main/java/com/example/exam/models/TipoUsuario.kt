package com.example.exam.models

data class TipoUsuario(
    val id: Int,
    val nombre: String
)
