package com.example.exam

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.exam.adapters.MateriasCrudAdapter
import com.example.exam.data.database.AppDatabaseHelper
import com.example.exam.data.database.MateriasDao
import com.example.exam.data.repository.MateriasRepository
import com.example.exam.models.Materias

class MateriaActivity : AppCompatActivity() {

    private lateinit var etNombreMateria: EditText
    private lateinit var etDescripcionMateria: EditText
    private lateinit var etDuracionMateria: EditText
    private lateinit var btnAgregar: Button
    private lateinit var btnActualizar: Button
    private lateinit var btnEliminar: Button
    private lateinit var recyclerMaterias: RecyclerView

    private lateinit var materiasRepository: MateriasRepository
    private var materiaSeleccionada: Materias? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_materia)

        // Inicializar vistas
        etNombreMateria = findViewById(R.id.etNombreMateria)
        etDescripcionMateria = findViewById(R.id.etDescripcionMateria)
        etDuracionMateria = findViewById(R.id.etDuracionMateria)
        btnAgregar = findViewById(R.id.btnAgregarMateria)
        btnActualizar = findViewById(R.id.btnActualizarMateria)
        btnEliminar = findViewById(R.id.btnEliminarMateria)
        recyclerMaterias = findViewById(R.id.recyclerMaterias)

        // Inicializar repositorio
        val dbHelper = AppDatabaseHelper(this)
        materiasRepository = MateriasRepository(MateriasDao(dbHelper))

        setupRecyclerView()
        setupClickListeners()
        cargarMaterias()
    }

    private fun setupRecyclerView() {
        recyclerMaterias.layoutManager = LinearLayoutManager(this)
    }

    private fun setupClickListeners() {
        btnAgregar.setOnClickListener { agregarMateria() }
        btnActualizar.setOnClickListener { actualizarMateria() }
        btnEliminar.setOnClickListener { eliminarMateria() }
    }

    private fun cargarMaterias() {
        val materias = materiasRepository.obtenerMaterias()
        recyclerMaterias.adapter = MateriasCrudAdapter(materias) { materia ->
            // Al hacer clic en un item, rellenar los campos
            materiaSeleccionada = materia
            etNombreMateria.setText(materia.nombre)
            etDescripcionMateria.setText(materia.descripcion)
            etDuracionMateria.setText(materia.duracion.toString())
        }
    }

    private fun agregarMateria() {
        val nombre = etNombreMateria.text.toString()
        val descripcion = etDescripcionMateria.text.toString()
        val duracion = etDuracionMateria.text.toString().toIntOrNull()

        if (nombre.isBlank() || duracion == null) {
            Toast.makeText(this, "Nombre y duración son obligatorios", Toast.LENGTH_SHORT).show()
            return
        }

        val nuevaMateria = Materias(0, nombre, descripcion, duracion, null) // id es 0 porque es autoincremental
        materiasRepository.agregarMateria(nuevaMateria)
        limpiarCampos()
        cargarMaterias() // Recargar la lista
        Toast.makeText(this, "Materia agregada", Toast.LENGTH_SHORT).show()
    }

    private fun actualizarMateria() {
        val materia = materiaSeleccionada ?: return

        val nombre = etNombreMateria.text.toString()
        val descripcion = etDescripcionMateria.text.toString()
        val duracion = etDuracionMateria.text.toString().toIntOrNull()

        if (nombre.isBlank() || duracion == null) {
            Toast.makeText(this, "Nombre y duración son obligatorios", Toast.LENGTH_SHORT).show()
            return
        }

        val materiaActualizada = materia.copy(nombre = nombre, descripcion = descripcion, duracion = duracion)
        materiasRepository.actualizarMateria(materiaActualizada)
        limpiarCampos()
        cargarMaterias()
        Toast.makeText(this, "Materia actualizada", Toast.LENGTH_SHORT).show()
    }

    private fun eliminarMateria() {
        val materia = materiaSeleccionada ?: return
        materiasRepository.eliminarMateria(materia.id)
        limpiarCampos()
        cargarMaterias()
        Toast.makeText(this, "Materia eliminada", Toast.LENGTH_SHORT).show()
    }

    private fun limpiarCampos() {
        etNombreMateria.text.clear()
        etDescripcionMateria.text.clear()
        etDuracionMateria.text.clear()
        materiaSeleccionada = null
    }
}
