package com.example.exam

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.exam.adapters.UserAdapter
import com.example.exam.data.database.AppDatabaseHelper
import com.example.exam.data.database.UsuarioDao
import com.example.exam.data.repository.UsuarioRepository
import com.example.exam.models.Usuario

class UserActivity : AppCompatActivity() {

    private lateinit var etNombre: EditText
    private lateinit var etPass: EditText
    private lateinit var etTipoUsuario: EditText
    private lateinit var btnAgregar: Button
    private lateinit var btnActualizar: Button
    private lateinit var btnEliminar: Button
    private lateinit var recyclerUsuarios: RecyclerView

    private lateinit var usuarioRepository: UsuarioRepository
    private var usuarioSeleccionado: Usuario? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user)

        // Inicializar vistas
        etNombre = findViewById(R.id.etNombre)
        etPass = findViewById(R.id.etPass)
        etTipoUsuario = findViewById(R.id.tipoUsuario)
        btnAgregar = findViewById(R.id.btnAgregarUsuario)
        btnActualizar = findViewById(R.id.btnActualizarUsuario)
        btnEliminar = findViewById(R.id.btnEliminarUsuario)
        recyclerUsuarios = findViewById(R.id.recyclerUsuarios)

        // Inicializar repositorio
        val dbHelper = AppDatabaseHelper(this)
        usuarioRepository = UsuarioRepository(UsuarioDao(dbHelper))

        setupRecyclerView()
        setupClickListeners()
        cargarUsuarios()
    }

    private fun setupRecyclerView() {
        recyclerUsuarios.layoutManager = LinearLayoutManager(this)
    }

    private fun setupClickListeners() {
        btnAgregar.setOnClickListener { agregarUsuario() }
        btnActualizar.setOnClickListener { actualizarUsuario() }
        btnEliminar.setOnClickListener { eliminarUsuario() }
    }

    private fun cargarUsuarios() {
        val usuarios = usuarioRepository.obtenerUsuarios()
        recyclerUsuarios.adapter = UserAdapter(usuarios) { usuario ->
            // Al hacer clic en un item, rellenar los campos
            usuarioSeleccionado = usuario
            etNombre.setText(usuario.usuario)
            etPass.setText(usuario.pass)
            etTipoUsuario.setText(usuario.idTipoUsuario.toString())
        }
    }

    private fun agregarUsuario() {
        val nombre = etNombre.text.toString()
        val pass = etPass.text.toString()
        val tipo = etTipoUsuario.text.toString().toIntOrNull()

        if (nombre.isBlank() || pass.isBlank() || tipo == null) {
            Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show()
            return
        }

        val nuevoUsuario = Usuario(0, nombre, pass, tipo)
        usuarioRepository.agregarUsuario(nuevoUsuario)
        limpiarCampos()
        cargarUsuarios() // Recargar la lista
        Toast.makeText(this, "Usuario agregado", Toast.LENGTH_SHORT).show()
    }

    private fun actualizarUsuario() {
        val usuario = usuarioSeleccionado ?: return

        val nombre = etNombre.text.toString()
        val pass = etPass.text.toString()
        val tipo = etTipoUsuario.text.toString().toIntOrNull()

        if (nombre.isBlank() || pass.isBlank() || tipo == null) {
            Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show()
            return
        }

        val usuarioActualizado = usuario.copy(usuario = nombre, pass = pass, idTipoUsuario = tipo)
        usuarioRepository.actualizarUsuario(usuarioActualizado)
        limpiarCampos()
        cargarUsuarios()
        Toast.makeText(this, "Usuario actualizado", Toast.LENGTH_SHORT).show()
    }

    private fun eliminarUsuario() {
        val usuario = usuarioSeleccionado ?: return
        usuarioRepository.eliminarUsuario(usuario.id)
        limpiarCampos()
        cargarUsuarios()
        Toast.makeText(this, "Usuario eliminado", Toast.LENGTH_SHORT).show()
    }

    private fun limpiarCampos() {
        etNombre.text.clear()
        etPass.text.clear()
        etTipoUsuario.text.clear()
        usuarioSeleccionado = null
    }
}
