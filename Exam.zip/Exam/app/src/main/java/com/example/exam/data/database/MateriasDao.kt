package com.example.exam.data.database

import android.content.ContentValues
import com.example.exam.models.Materias

class MateriasDao(private val dbHelper: AppDatabaseHelper) {

    fun insert(materia: Materias): Long {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("nombre", materia.nombre)
            put("descripcion", materia.descripcion)
            put("duracion", materia.duracion)
            put("idDiplomado", materia.idDiplomado)
        }
        return db.insert("Materias", null, values)
    }

    fun getAll(): List<Materias> {
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM Materias", null)
        val lista = mutableListOf<Materias>()

        if (cursor.moveToFirst()) {
            do {
                lista.add(
                    Materias(
                        id = cursor.getInt(0),
                        nombre = cursor.getString(1),
                        descripcion = cursor.getString(2),
                        duracion = cursor.getInt(3),
                        idDiplomado = cursor.getInt(4)
                    )
                )
            } while (cursor.moveToNext())
        }

        cursor.close()
        return lista
    }

    fun getById(id: Int): Materias? {
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM Materias WHERE id = ?", arrayOf(id.toString()))
        var materia: Materias? = null
        if (cursor.moveToFirst()) {
            materia = Materias(
                id = cursor.getInt(0),
                nombre = cursor.getString(1),
                descripcion = cursor.getString(2),
                duracion = cursor.getInt(3),
                idDiplomado = cursor.getInt(4)
            )
        }
        cursor.close()
        return materia
    }

    fun update(materia: Materias): Int {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("nombre", materia.nombre)
            put("descripcion", materia.descripcion)
            put("duracion", materia.duracion)
            put("idDiplomado", materia.idDiplomado)
        }
        return db.update("Materias", values, "id = ?", arrayOf(materia.id.toString()))
    }

    fun delete(id: Int): Int {
        val db = dbHelper.writableDatabase
        return db.delete("Materias", "id = ?", arrayOf(id.toString()))
    }
}
