package com.example.exam.data.database

import android.content.ContentValues
import com.example.exam.models.UsuarioDiplomado

class UsuarioDiplomadoDao(private val dbHelper: AppDatabaseHelper) {

    fun insert(usuarioDiplomado: UsuarioDiplomado): Long {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("idUsuario", usuarioDiplomado.idUsuario)
            put("idDiplomado", usuarioDiplomado.idDiplomado)
        }
        return db.insert("UsuarioDiplomado", null, values)
    }

    fun getAll(): List<UsuarioDiplomado> {
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM UsuarioDiplomado", null)
        val lista = mutableListOf<UsuarioDiplomado>()
        if (cursor.moveToFirst()) {
            val idUsuarioIndex = cursor.getColumnIndex("idUsuario")
            val idDiplomadoIndex = cursor.getColumnIndex("idDiplomado")
            do {
                if (idUsuarioIndex != -1 && idDiplomadoIndex != -1) {
                    lista.add(
                        UsuarioDiplomado(
                            idUsuario = cursor.getInt(idUsuarioIndex),
                            idDiplomado = cursor.getInt(idDiplomadoIndex)
                        )
                    )
                }
            } while (cursor.moveToNext())
        }
        cursor.close()
        return lista
    }

    fun delete(idUsuario: Int, idDiplomado: Int): Int {
        val db = dbHelper.writableDatabase
        return db.delete("UsuarioDiplomado", "idUsuario = ? AND idDiplomado = ?", arrayOf(idUsuario.toString(), idDiplomado.toString()))
    }
}
