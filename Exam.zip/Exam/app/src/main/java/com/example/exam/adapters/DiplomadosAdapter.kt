package com.example.exam.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.exam.R
import com.example.exam.models.Diplomado

class DiplomadosAdapter(
    private val lista: List<Diplomado>,
    private val onItemClicked: (Diplomado) -> Unit // Usamos una función lambda en lugar del booleano
) : RecyclerView.Adapter<DiplomadosAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTitulo: TextView = view.findViewById(R.id.tvDiplomado)
        val tvDesc: TextView = view.findViewById(R.id.tvDescripcion)
        val tvInicio: TextView = view.findViewById(R.id.tvFechaInicio)
        val tvFin: TextView = view.findViewById(R.id.tvFechafIN)
        val tvStatus: TextView = view.findViewById(R.id.tvEstatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.view_dip, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = lista[position]

        holder.tvTitulo.text = "Diplomado: ${item.nombre}"
        holder.tvDesc.text = "Descripción: ${item.descripcion ?: "No disponible"}"
        holder.tvInicio.text = "Fecha Inicio: ${item.fechaInicio}"
        holder.tvFin.text = "Fecha Finalización: ${item.fechaFin}"
        holder.tvStatus.text = "Estatus: ${if (item.isActivo == 1) "Activo" else "Inactivo"}"

        // Al hacer clic, simplemente llamamos a la función lambda que nos pasaron
        holder.itemView.setOnClickListener { onItemClicked(item) }
    }

    override fun getItemCount(): Int = lista.size
}
