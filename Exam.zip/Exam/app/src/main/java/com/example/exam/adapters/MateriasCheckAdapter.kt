package com.example.exam.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import androidx.recyclerview.widget.RecyclerView
import com.example.exam.R
import com.example.exam.models.Materias

class MateriasCheckAdapter(
    private val materias: List<Materias>
) : RecyclerView.Adapter<MateriasCheckAdapter.ViewHolder>() {

    private val materiasSeleccionadas = mutableSetOf<Int>()

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val checkBox: CheckBox = view.findViewById(R.id.cbMateria)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_materia_check, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val materia = materias[position]
        holder.checkBox.text = materia.nombre
        holder.checkBox.isChecked = materiasSeleccionadas.contains(materia.id)

        holder.checkBox.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                materiasSeleccionadas.add(materia.id)
            } else {
                materiasSeleccionadas.remove(materia.id)
            }
        }
    }

    override fun getItemCount(): Int = materias.size

    fun getMateriasSeleccionadasIds(): List<Int> = materiasSeleccionadas.toList()

    fun setMateriasSeleccionadas(ids: List<Int>) {
        materiasSeleccionadas.clear()
        materiasSeleccionadas.addAll(ids)
        notifyDataSetChanged()
    }
}
