package com.example.exam.models

data class Materias(
    val id: Int,
    val nombre: String,
    val descripcion: String?,
    val duracion: Int,
    val idDiplomado: Int?
)