package com.example.exam.data.repository

import com.example.exam.data.database.UsuarioDiplomadoDao
import com.example.exam.models.UsuarioDiplomado

class UsuarioDiplomadoRepository(private val usuarioDiplomadoDao: UsuarioDiplomadoDao) {

    fun agregarUsuarioDiplomado(usuarioDiplomado: UsuarioDiplomado) = usuarioDiplomadoDao.insert(usuarioDiplomado)

    fun obtenerTodasLasRelaciones(): List<UsuarioDiplomado> = usuarioDiplomadoDao.getAll()

    fun eliminarUsuarioDiplomado(idUsuario: Int, idDiplomado: Int) = usuarioDiplomadoDao.delete(idUsuario, idDiplomado)
}
