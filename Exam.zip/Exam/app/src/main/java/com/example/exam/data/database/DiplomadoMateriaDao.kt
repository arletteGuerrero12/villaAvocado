package com.example.exam.data.database

import android.content.ContentValues
import com.example.exam.models.DiplomadoMateria

class DiplomadoMateriaDao(private val dbHelper: AppDatabaseHelper) {

    fun insert(diplomadoMateria: DiplomadoMateria): Long {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("idDiplomado", diplomadoMateria.idDiplomado)
            put("idMateria", diplomadoMateria.idMateria)
        }
        return db.insert("DiplomadoMateria", null, values)
    }

    fun getAll(): List<DiplomadoMateria> {
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM DiplomadoMateria", null)
        val lista = mutableListOf<DiplomadoMateria>()

        if (cursor.moveToFirst()) {
            val idDiplomadoIndex = cursor.getColumnIndex("idDiplomado")
            val idMateriaIndex = cursor.getColumnIndex("idMateria")
            do {
                if (idDiplomadoIndex != -1 && idMateriaIndex != -1) {
                    lista.add(
                        DiplomadoMateria(
                            idDiplomado = cursor.getInt(idDiplomadoIndex),
                            idMateria = cursor.getInt(idMateriaIndex)
                        )
                    )
                }
            } while (cursor.moveToNext())
        }

        cursor.close()
        return lista
    }

    fun delete(idDiplomado: Int, idMateria: Int): Int {
        val db = dbHelper.writableDatabase
        return db.delete("DiplomadoMateria", "idDiplomado = ? AND idMateria = ?", arrayOf(idDiplomado.toString(), idMateria.toString()))
    }
}
