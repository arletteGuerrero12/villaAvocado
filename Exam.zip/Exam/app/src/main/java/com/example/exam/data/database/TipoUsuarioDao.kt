package com.example.exam.data.database

import android.content.ContentValues
import com.example.exam.models.TipoUsuario

class TipoUsuarioDao(private val dbHelper: AppDatabaseHelper) {

    fun insert(tipoUsuario: TipoUsuario): Long {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("nombre", tipoUsuario.nombre)
        }
        return db.insert("TipoUsuario", null, values)
    }

    fun getAll(): List<TipoUsuario> {
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM TipoUsuario", null)
        val lista = mutableListOf<TipoUsuario>()

        if (cursor.moveToFirst()) {
            do {
                lista.add(
                    TipoUsuario(
                        id = cursor.getInt(0),
                        nombre = cursor.getString(1)
                    )
                )
            } while (cursor.moveToNext())
        }

        cursor.close()
        return lista
    }

    fun getById(id: Int): TipoUsuario? {
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM TipoUsuario WHERE id = ?", arrayOf(id.toString()))
        var tipoUsuario: TipoUsuario? = null
        if (cursor.moveToFirst()) {
            tipoUsuario = TipoUsuario(
                id = cursor.getInt(0),
                nombre = cursor.getString(1)
            )
        }
        cursor.close()
        return tipoUsuario
    }

    fun update(tipoUsuario: TipoUsuario): Int {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("nombre", tipoUsuario.nombre)
        }
        return db.update("TipoUsuario", values, "id = ?", arrayOf(tipoUsuario.id.toString()))
    }

    fun delete(id: Int): Int {
        val db = dbHelper.writableDatabase
        return db.delete("TipoUsuario", "id = ?", arrayOf(id.toString()))
    }
}
