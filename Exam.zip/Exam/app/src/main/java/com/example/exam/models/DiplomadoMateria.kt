package com.example.exam.models

data class DiplomadoMateria(
    val idDiplomado: Int,
    val idMateria: Int
)
