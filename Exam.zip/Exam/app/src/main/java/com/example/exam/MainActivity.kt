package com.example.exam

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.exam.data.database.AppDatabaseHelper
import com.example.exam.data.database.UsuarioDao
import com.example.exam.data.repository.UsuarioRepository

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.statusBarColor = Color.DKGRAY

        val btnEntrar = findViewById<Button>(R.id.btnLogin)
        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etPassword = findViewById<EditText>(R.id.etPassword)

        val dbHelper = AppDatabaseHelper(this)
        val usuarioDao = UsuarioDao(dbHelper)
        val usuarioRepository = UsuarioRepository(usuarioDao)

        btnEntrar.setOnClickListener {
            val email = etEmail.text.toString()
            val password = etPassword.text.toString()

            if (email.isNotEmpty() && password.isNotEmpty()) {
                val usuarios = usuarioRepository.obtenerUsuarios()
                val foundUser = usuarios.find { it.usuario == email && it.pass == password }

                if (foundUser != null) {
                    when (foundUser.idTipoUsuario) {
                        1 -> {
                            val intent = Intent(this, AdminActivity::class.java)
                            startActivity(intent)
                        }
                        2 -> {
                            val intent = Intent(this, HomeActivity::class.java)
                            intent.putExtra("USER_ID", foundUser.id)
                            startActivity(intent)
                        }
                        else -> {
                            Toast.makeText(this, "Tipo de usuario no reconocido", Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    Toast.makeText(this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
