package com.example.exam.adapters

import android.app.AlertDialog
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.exam.R
import com.example.exam.models.Diplomado

class DiplomadoAdapter(
    private val lista: List<Diplomado>,
    private val enableClick: Boolean   // ← esto activa/desactiva el click
) : RecyclerView.Adapter<DiplomadoAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val box: LinearLayout = view.findViewById(R.id.box)
        val tvTitulo: TextView = view.findViewById(R.id.tvDiplomado)
        val tvDesc: TextView = view.findViewById(R.id.tvDescripcion)
        val tvInicio: TextView = view.findViewById(R.id.tvFechaInicio)
        val tvFin: TextView = view.findViewById(R.id.tvFechafIN)
        val tvStatus: TextView = view.findViewById(R.id.tvEstatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.view_dip, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val ctx = holder.itemView.context
        val item = lista[position]

        holder.tvTitulo.text = "Diplomado: ${item.nombre}"
        holder.tvDesc.text = "Descripción: ${item.descripcion}"
        holder.tvInicio.text = "Fecha Inicio: ${item.fechaInicio}"
        holder.tvFin.text = "Fecha Finalización: ${item.fechaFin}"
        holder.tvStatus.text = "Estatus: ${item.isActivo}"

        // -----------------------------------------
        //     SI enableClick ES TRUE → popup
        // -----------------------------------------
        if (enableClick) {
            holder.box.setOnClickListener {


                val dialog = AlertDialog.Builder(ctx)
                    .setTitle("📘 ${item.nombre}")
                    .setMessage(
                        "¿Deseas inscribirte a este diplomado?\n\n" +
                                "📅 Fechas:\n" +
                                "   • Inicio: ${item.fechaInicio}\n" +
                                "   • Fin: ${item.fechaFin}\n\n"
                    )
                    .setPositiveButton("Inscribirme") { dialog, _ ->
                        Toast.makeText(ctx, "Inscrito correctamente", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("Cancelar") { dialog, _ ->
                        dialog.dismiss()
                    }
                    .setCancelable(true)
                    .create()

                dialog.show()

                // 🎨 Estilo de botones (se mantiene igual)
                dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(ctx.getColor(R.color.teal_700))
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(ctx.getColor(R.color.red))
            }


        } else {
            // SIN CLICK
            holder.box.setOnClickListener(null)
        }
    }

    override fun getItemCount(): Int = lista.size
}
