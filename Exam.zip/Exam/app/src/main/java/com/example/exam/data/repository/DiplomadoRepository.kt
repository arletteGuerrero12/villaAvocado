package com.example.exam.data.repository

import com.example.exam.data.database.DiplomadoDao
import com.example.exam.models.Diplomado

class DiplomadoRepository(private val diplomadoDao: DiplomadoDao) {

    fun agregarDiplomado(diplomado: Diplomado) = diplomadoDao.insert(diplomado)

    fun obtenerDiplomado() = diplomadoDao.getAll()

    fun eliminarDiplomado(id: Int) = diplomadoDao.delete(id)

    fun actualizarDiplomado(diplomado: Diplomado) = diplomadoDao.update(diplomado)

    fun obtenerDiplomadoPorId(id: Int) = diplomadoDao.getById(id)

}
