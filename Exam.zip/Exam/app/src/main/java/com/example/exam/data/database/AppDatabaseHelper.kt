package com.example.exam.data.database

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class AppDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "exam_database.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {

        db.execSQL("""
            CREATE TABLE TipoUsuario(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL
            );
        """)

        db.execSQL("""
            CREATE TABLE Usuario(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario TEXT NOT NULL,
                pass TEXT NOT NULL,
                idTipoUsuario INTEGER,
                FOREIGN KEY(idTipoUsuario) REFERENCES TipoUsuario(id)
            );
        """)

        db.execSQL("""
            CREATE TABLE Diplomado(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL,
                descripcion TEXT,
                isActivo INTEGER,
                fechaInserto TEXT,
                fechaInicio TEXT,
                fechaFin TEXT
            );
        """)

        db.execSQL("""
            CREATE TABLE Materias(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL,
                descripcion TEXT,
                duracion INTEGER,
                idDiplomado INTEGER,
                FOREIGN KEY(idDiplomado) REFERENCES Diplomado(id)
            );
        """)

        db.execSQL("""
            CREATE TABLE DiplomadoMateria(
                idDiplomado INTEGER,
                idMateria INTEGER,
                PRIMARY KEY(idDiplomado, idMateria),
                FOREIGN KEY(idDiplomado) REFERENCES Diplomado(id),
                FOREIGN KEY(idMateria) REFERENCES Materias(id)
            );
        """)

        db.execSQL("""
            CREATE TABLE UsuarioDiplomado(
                idUsuario INTEGER,
                idDiplomado INTEGER,
                PRIMARY KEY(idUsuario, idDiplomado),
                FOREIGN KEY(idUsuario) REFERENCES Usuario(id),
                FOREIGN KEY(idDiplomado) REFERENCES Diplomado(id)
            );
        """)

        // ------------------------
// TIPOS DE USUARIO
// ------------------------
        db.execSQL("INSERT INTO TipoUsuario(nombre) VALUES ('Admin');")
        db.execSQL("INSERT INTO TipoUsuario(nombre) VALUES ('Alumno');")


// ------------------------
// USUARIOS
// ------------------------
        db.execSQL("INSERT INTO Usuario(usuario, pass, idTipoUsuario) VALUES ('admin', '1234', 1);")
        db.execSQL("INSERT INTO Usuario(usuario, pass, idTipoUsuario) VALUES ('juan', 'pass1', 1);")
        db.execSQL("INSERT INTO Usuario(usuario, pass, idTipoUsuario) VALUES ('maria', 'pass2', 2);")
        db.execSQL("INSERT INTO Usuario(usuario, pass, idTipoUsuario) VALUES ('pedro', 'pass3', 2);")


// ------------------------
// DIPLOMADOS
// ------------------------
        db.execSQL("INSERT INTO Diplomado(nombre, descripcion, isActivo, fechaInserto, fechaInicio, fechaFin) " +
                "VALUES ('Desarrollo Android', 'Diplomado completo sobre apps móviles', 1, '2025-01-10', '2025-02-01', '2025-06-30');")
        db.execSQL("INSERT INTO Diplomado(nombre, descripcion, isActivo, fechaInserto, fechaInicio, fechaFin) " +
                "VALUES ('Ciberseguridad', 'Análisis, auditoría y respuesta a incidentes', 1, '2025-01-12', '2025-03-01', '2025-07-15');")
        db.execSQL("INSERT INTO Diplomado(nombre, descripcion, isActivo, fechaInserto, fechaInicio, fechaFin) " +
                "VALUES ('Redes y Telecomunicaciones', 'Infraestructura, routers, protocolos', 0, '2025-01-05', '2025-04-01', '2025-08-20');")
        db.execSQL("INSERT INTO Diplomado(nombre, descripcion, isActivo, fechaInserto, fechaInicio, fechaFin) " +
                "VALUES ('Bases de Datos', 'SQL, NoSQL y optimización', 1, '2025-01-20', '2025-02-15', '2025-06-15');")
        db.execSQL("INSERT INTO Diplomado(nombre, descripcion, isActivo, fechaInserto, fechaInicio, fechaFin) " +
                "VALUES ('Inteligencia Artificial', 'IA y Machine Learning', 1, '2025-01-22', '2025-03-01', '2025-07-01');")
        db.execSQL("INSERT INTO Diplomado(nombre, descripcion, isActivo, fechaInserto, fechaInicio, fechaFin) " +
                "VALUES ('IoT', 'Internet de las cosas y sensores', 1, '2025-01-25', '2025-03-15', '2025-08-15');")
        db.execSQL("INSERT INTO Diplomado(nombre, descripcion, isActivo, fechaInserto, fechaInicio, fechaFin) " +
                "VALUES ('Metaverso y Realidad Virtual', 'Tecnologías inmersivas', 1, '2025-01-28', '2025-04-01', '2025-08-30');")
        db.execSQL("INSERT INTO Diplomado(nombre, descripcion, isActivo, fechaInserto, fechaInicio, fechaFin) " +
                "VALUES ('Blockchain', 'Criptografía y cadenas de bloques', 1, '2026-01-30', '2026-04-15', '2026-09-01');")
        db.execSQL("INSERT INTO Diplomado(nombre, descripcion, isActivo, fechaInserto, fechaInicio, fechaFin) " +
                "VALUES ('Big Data', 'Procesamiento y análisis de datos masivos', 1, '2026-02-01', '2026-04-20', '2026-09-20');")
        db.execSQL("INSERT INTO Diplomado(nombre, descripcion, isActivo, fechaInserto, fechaInicio, fechaFin) " +
                "VALUES ('Cloud Computing', 'Servicios en la nube y DevOps', 1, '2026-02-05', '2026-05-01', '2026-09-30');")

// ------------------------
// MATERIAS
// ------------------------
        val materias = listOf(
            Triple("Kotlin Básico", "Introducción al lenguaje Kotlin", 20),
            Triple("Android Avanzado", "Arquitecturas MVVM y Jetpack", 35),
            Triple("UI/UX Mobile", "Diseño de interfaces modernas", 15),
            Triple("Fundamentos de Seguridad", "Conceptos base de ciberseguridad", 25),
            Triple("Pentesting", "Pruebas de intrusión", 40),
            Triple("Forensia Digital", "Investigación de incidentes", 30),
            Triple("Protocolos de Red", "TCP/IP, DNS, DHCP", 18),
            Triple("Conmutación y Enrutamiento", "Routers y switches", 22),
            Triple("SQL Avanzado", "Optimización, triggers y vistas", 28),
            Triple("MongoDB & NoSQL", "Bases NoSQL modernas", 25),
            Triple("Machine Learning", "Aprendizaje automático y modelos", 30),
            Triple("Redes Neuronales", "Deep Learning avanzado", 35),
            Triple("Sensores IoT", "Configuración y manejo de sensores", 20),
            Triple("Aplicaciones IoT", "Integración con plataformas", 25),
            Triple("VR/AR Básico", "Realidad virtual y aumentada", 20),
            Triple("Unity VR", "Desarrollo en Unity para VR", 30),
            Triple("Blockchain Básico", "Conceptos y criptografía", 20),
            Triple("Smart Contracts", "Programación de contratos inteligentes", 30),
            Triple("Big Data Analytics", "Procesamiento de datos masivos", 25),
            Triple("Cloud DevOps", "Automatización en la nube", 20)
        )

        materias.forEach { (nombre, desc, dur) ->
            db.execSQL("INSERT INTO Materias(nombre, descripcion, duracion) VALUES ('$nombre', '$desc', $dur);")
        }

// ------------------------
// RELACIONES DIPLOMADO - MATERIA
// ------------------------
// Diplomado 1: Desarrollo Android
        db.execSQL("INSERT INTO DiplomadoMateria(idDiplomado, idMateria) VALUES (1, 1);")
        db.execSQL("INSERT INTO DiplomadoMateria(idDiplomado, idMateria) VALUES (1, 2);")
        db.execSQL("INSERT INTO DiplomadoMateria(idDiplomado, idMateria) VALUES (1, 3);")

// Diplomado 2: Ciberseguridad
        db.execSQL("INSERT INTO DiplomadoMateria(idDiplomado, idMateria) VALUES (2, 4);")
        db.execSQL("INSERT INTO DiplomadoMateria(idDiplomado, idMateria) VALUES (2, 5);")
        db.execSQL("INSERT INTO DiplomadoMateria(idDiplomado, idMateria) VALUES (2, 6);")

// Diplomado 3: Redes y Telecomunicaciones
        db.execSQL("INSERT INTO DiplomadoMateria(idDiplomado, idMateria) VALUES (3, 7);")
        db.execSQL("INSERT INTO DiplomadoMateria(idDiplomado, idMateria) VALUES (3, 8);")

// Diplomado 4: Bases de Datos
        db.execSQL("INSERT INTO DiplomadoMateria(idDiplomado, idMateria) VALUES (4, 9);")
        db.execSQL("INSERT INTO DiplomadoMateria(idDiplomado, idMateria) VALUES (4, 10);")

// Diplomado 5: Inteligencia Artificial
        db.execSQL("INSERT INTO DiplomadoMateria(idDiplomado, idMateria) VALUES (5, 11);")
        db.execSQL("INSERT INTO DiplomadoMateria(idDiplomado, idMateria) VALUES (5, 12);")

// Diplomado 6: IoT
        db.execSQL("INSERT INTO DiplomadoMateria(idDiplomado, idMateria) VALUES (6, 13);")
        db.execSQL("INSERT INTO DiplomadoMateria(idDiplomado, idMateria) VALUES (6, 14);")

// Diplomado 7: Metaverso y VR
        db.execSQL("INSERT INTO DiplomadoMateria(idDiplomado, idMateria) VALUES (7, 15);")
        db.execSQL("INSERT INTO DiplomadoMateria(idDiplomado, idMateria) VALUES (7, 16);")

// Diplomado 8: Blockchain
        db.execSQL("INSERT INTO DiplomadoMateria(idDiplomado, idMateria) VALUES (8, 17);")
        db.execSQL("INSERT INTO DiplomadoMateria(idDiplomado, idMateria) VALUES (8, 18);")

// Diplomado 9: Big Data
        db.execSQL("INSERT INTO DiplomadoMateria(idDiplomado, idMateria) VALUES (9, 19);")

// Diplomado 10: Cloud Computing
        db.execSQL("INSERT INTO DiplomadoMateria(idDiplomado, idMateria) VALUES (10, 20);")
// ------------------------
// RELACIONES USUARIO - DIPLOMADO
// ------------------------
        db.execSQL("INSERT INTO UsuarioDiplomado(idUsuario, idDiplomado) VALUES (3, 1);") // maria -> Desarrollo Android
        db.execSQL("INSERT INTO UsuarioDiplomado(idUsuario, idDiplomado) VALUES (3, 2);") // pedro -> Ciberseguridad
        db.execSQL("INSERT INTO UsuarioDiplomado(idUsuario, idDiplomado) VALUES (3, 4);") // maria -> Bases de Datos


    }


    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    companion object {
        private const val DATABASE_NAME = "exam.db"
        private const val DATABASE_VERSION = 1
    }
}
