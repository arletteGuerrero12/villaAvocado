package com.example.exam.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.exam.R
import com.example.exam.models.Materias

class MateriasAdapter(private var materias: List<Materias>) : RecyclerView.Adapter<MateriasAdapter.MateriaViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MateriaViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_materia, parent, false)
        return MateriaViewHolder(view)
    }

    override fun onBindViewHolder(holder: MateriaViewHolder, position: Int) {
        holder.bind(materias[position])
    }

    override fun getItemCount(): Int = materias.size

    fun updateMaterias(newMaterias: List<Materias>) {
        materias = newMaterias
        notifyDataSetChanged()
    }

    class MateriaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvNombreMateria: TextView = itemView.findViewById(R.id.tvNombreMateria)

        fun bind(materia: Materias) {
            tvNombreMateria.text = materia.nombre
        }
    }
}
