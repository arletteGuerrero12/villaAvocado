package com.example.exam.models

import kotlin.jvm.Transient

data class Diplomado(
    val id: Int,
    val nombre: String,
    val descripcion: String?,
    val isActivo: Int,
    val fechaInserto: String,
    val fechaInicio: String,
    val fechaFin: String,
    @Transient var materias: List<Materias> = emptyList()
)
