package com.example.exam.models

data class Usuario(
    val id: Int = 0,
    val usuario: String,
    val pass: String,
    val idTipoUsuario: Int
)
