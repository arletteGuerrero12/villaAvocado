package com.example.exam.data.repository

import com.example.exam.data.database.DiplomadoMateriaDao
import com.example.exam.models.DiplomadoMateria

class DiplomadoMateriaRepository(private val diplomadoMateriaDao: DiplomadoMateriaDao) {
    fun obtenerDiplomadoMaterias(): List<DiplomadoMateria> = diplomadoMateriaDao.getAll()
    fun agregarDiplomadoMateria(diplomadoMateria: DiplomadoMateria): Long = diplomadoMateriaDao.insert(diplomadoMateria)
    fun eliminarDiplomadoMateria(idDiplomado: Int, idMateria: Int): Int = diplomadoMateriaDao.delete(idDiplomado, idMateria)
}
