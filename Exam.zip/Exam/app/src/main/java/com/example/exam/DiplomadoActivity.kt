package com.example.exam

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.exam.adapters.DiplomadosAdapter
import com.example.exam.adapters.MateriasCheckAdapter
import com.example.exam.data.database.AppDatabaseHelper
import com.example.exam.data.database.DiplomadoDao
import com.example.exam.data.database.DiplomadoMateriaDao
import com.example.exam.data.database.MateriasDao
import com.example.exam.data.repository.DiplomadoMateriaRepository
import com.example.exam.data.repository.DiplomadoRepository
import com.example.exam.data.repository.MateriasRepository
import com.example.exam.models.Diplomado
import com.example.exam.models.DiplomadoMateria

class DiplomadoActivity : AppCompatActivity() {

    private lateinit var etNombre: EditText
    private lateinit var etDescripcion: EditText
    private lateinit var etFechaInicio: EditText
    private lateinit var etFechaFin: EditText
    private lateinit var recyclerMateriasCheck: RecyclerView
    private lateinit var recyclerDiplomados: RecyclerView
    private lateinit var btnAgregar: Button
    private lateinit var btnActualizar: Button
    private lateinit var btnEliminar: Button

    private lateinit var diplomadoRepository: DiplomadoRepository
    private lateinit var materiasRepository: MateriasRepository
    private lateinit var diplomadoMateriaRepository: DiplomadoMateriaRepository

    private var diplomadoSeleccionado: Diplomado? = null
    private lateinit var materiasCheckAdapter: MateriasCheckAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_diplomado)

        // Inicializar vistas
        etNombre = findViewById(R.id.etNombreDiplomado)
        etDescripcion = findViewById(R.id.etDescripcionDiplomado)
        etFechaInicio = findViewById(R.id.etFechaInicio)
        etFechaFin = findViewById(R.id.etFechaFin)
        recyclerMateriasCheck = findViewById(R.id.recyclerMateriasCheck)
        recyclerDiplomados = findViewById(R.id.recyclerDiplomados)
        btnAgregar = findViewById(R.id.btnAgregarDiplomado)
        btnActualizar = findViewById(R.id.btnActualizarDiplomado)
        btnEliminar = findViewById(R.id.btnEliminarDiplomado)

        // Inicializar repositorios
        val dbHelper = AppDatabaseHelper(this)
        diplomadoRepository = DiplomadoRepository(DiplomadoDao(dbHelper))
        materiasRepository = MateriasRepository(MateriasDao(dbHelper))
        diplomadoMateriaRepository = DiplomadoMateriaRepository(DiplomadoMateriaDao(dbHelper))

        setupRecyclerViews()
        setupClickListeners()
        cargarDatos()
    }

    private fun setupRecyclerViews() {
        recyclerMateriasCheck.layoutManager = LinearLayoutManager(this)
        recyclerDiplomados.layoutManager = LinearLayoutManager(this)
    }

    private fun setupClickListeners() {
        btnAgregar.setOnClickListener { agregarDiplomado() }
        btnActualizar.setOnClickListener { actualizarDiplomado() }
        btnEliminar.setOnClickListener { eliminarDiplomado() }
    }

    private fun cargarDatos() {
        // Cargar materias en el recycler de checkboxes
        val todasLasMaterias = materiasRepository.obtenerMaterias()
        materiasCheckAdapter = MateriasCheckAdapter(todasLasMaterias)
        recyclerMateriasCheck.adapter = materiasCheckAdapter

        // Cargar diplomados existentes
        val diplomados = diplomadoRepository.obtenerDiplomado()
        recyclerDiplomados.adapter = DiplomadosAdapter(diplomados) { diplomado ->
            diplomadoSeleccionado = diplomado
            etNombre.setText(diplomado.nombre)
            etDescripcion.setText(diplomado.descripcion)
            etFechaInicio.setText(diplomado.fechaInicio)
            etFechaFin.setText(diplomado.fechaFin)

            // Marcar las materias que ya tiene el diplomado
            val idsMateriasDelDiplomado = diplomadoMateriaRepository.obtenerDiplomadoMaterias()
                .filter { it.idDiplomado == diplomado.id }
                .map { it.idMateria }
            materiasCheckAdapter.setMateriasSeleccionadas(idsMateriasDelDiplomado)
        }
    }

    private fun agregarDiplomado() {
        val nombre = etNombre.text.toString()
        if (nombre.isBlank()) {
            Toast.makeText(this, "El nombre es obligatorio", Toast.LENGTH_SHORT).show()
            return
        }

        val nuevoDiplomado = Diplomado(0, nombre, etDescripcion.text.toString(), 1, "", etFechaInicio.text.toString(), etFechaFin.text.toString())
        val nuevoId = diplomadoRepository.agregarDiplomado(nuevoDiplomado)

        // Guardar relaciones
        val idsMaterias = materiasCheckAdapter.getMateriasSeleccionadasIds()
        idsMaterias.forEach {
            diplomadoMateriaRepository.agregarDiplomadoMateria(DiplomadoMateria(nuevoId.toInt(), it))
        }

        limpiarYRecargar()
        Toast.makeText(this, "Diplomado agregado", Toast.LENGTH_SHORT).show()
    }

    private fun actualizarDiplomado() {
        val diplomado = diplomadoSeleccionado ?: return

        val diplomadoActualizado = diplomado.copy(
            nombre = etNombre.text.toString(),
            descripcion = etDescripcion.text.toString(),
            fechaInicio = etFechaInicio.text.toString(),
            fechaFin = etFechaFin.text.toString()
        )
        diplomadoRepository.actualizarDiplomado(diplomadoActualizado)

        // Actualizar relaciones (borrar las viejas y crear las nuevas)
        diplomadoMateriaRepository.obtenerDiplomadoMaterias().filter { it.idDiplomado == diplomado.id }.forEach {
            diplomadoMateriaRepository.eliminarDiplomadoMateria(it.idDiplomado, it.idMateria)
        }
        materiasCheckAdapter.getMateriasSeleccionadasIds().forEach {
            diplomadoMateriaRepository.agregarDiplomadoMateria(DiplomadoMateria(diplomado.id, it))
        }

        limpiarYRecargar()
        Toast.makeText(this, "Diplomado actualizado", Toast.LENGTH_SHORT).show()
    }

    private fun eliminarDiplomado() {
        val diplomado = diplomadoSeleccionado ?: return

        // Primero, eliminar relaciones
        diplomadoMateriaRepository.obtenerDiplomadoMaterias().filter { it.idDiplomado == diplomado.id }.forEach {
            diplomadoMateriaRepository.eliminarDiplomadoMateria(it.idDiplomado, it.idMateria)
        }
        // Luego, eliminar el diplomado
        diplomadoRepository.eliminarDiplomado(diplomado.id)

        limpiarYRecargar()
        Toast.makeText(this, "Diplomado eliminado", Toast.LENGTH_SHORT).show()
    }

    private fun limpiarYRecargar() {
        etNombre.text.clear()
        etDescripcion.text.clear()
        etFechaInicio.text.clear()
        etFechaFin.text.clear()
        diplomadoSeleccionado = null
        materiasCheckAdapter.setMateriasSeleccionadas(emptyList())
        cargarDatos()
    }
}
